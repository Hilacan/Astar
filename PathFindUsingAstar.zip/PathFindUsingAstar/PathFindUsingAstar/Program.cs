﻿using System;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;


namespace PathFindUsingAstar
{
    class grid
    {
        public int A;
        public int B;
        public int C;
        public int D;
        public int E;
        public grid Origin;

    }
    class Program
    {
        static void Main(string[] args)
        {
            //You can add walls here using the 'X' and also manipulate the box
            string[] map = new string[]
            {
                "+-------+",
                "|     X |",
                "|A XX X |",
                "|XXX    |",
                "|    X  |",
                "|   XX  |",
                "| B     |",
                "+-------+",
            };

            foreach (var line in map)
                Console.WriteLine(line);
            // algo
            //you can change the staring(A) and the Goal(B) by manualy changing it both in the s and t grid below and the string above
            grid current = null;
            var s = new grid { A = 1, B = 2 };
            var t = new grid { A = 2, B = 6 };
            var ol = new List<grid>();
            var cl = new List<grid>();
            int g = 0;

           
            ol.Add(s);

            while (ol.Count > 0)
            {
          
                var lowest = ol.Min(l => l.B);
                current = ol.First(l => l.B == lowest);
              
                cl.Add(current);
                // show current square on the map using '*'
                Console.SetCursorPosition(current.A, current.B);
                Console.Write('*');
                Console.SetCursorPosition(current.A, current.B);
                System.Threading.Thread.Sleep(1000);
             
                ol.Remove(current);
              
                if (cl.FirstOrDefault(l => l.A == t.A && l.B == t.B) != null)
                    break;

                var adjacentSquares = AsquareOpen(current.A, current.B, map);
                g++;

                foreach (var adjacentSquare in adjacentSquares)
                {
                    if (cl.FirstOrDefault(l => l.A == adjacentSquare.A
                            && l.B == adjacentSquare.B) != null)
                        continue;
                    if (ol.FirstOrDefault(l => l.A == adjacentSquare.A
                            && l.B == adjacentSquare.B) == null)
                    {
                     
                        adjacentSquare.D = g;
                        adjacentSquare.E = ComputeHScore(adjacentSquare.A, adjacentSquare.B, t.A, t.B);
                        adjacentSquare.C = adjacentSquare.D + adjacentSquare.E;
                        adjacentSquare.Origin = current;

                        
                        ol.Insert(0, adjacentSquare);
                    }
                    else
                    {
                        
                        if (g + adjacentSquare.D < adjacentSquare.C)
                        {
                            adjacentSquare.D = g;
                            adjacentSquare.C = adjacentSquare.D + adjacentSquare.D;
                            adjacentSquare.Origin = current;
                        }
                    }
                }
            }

            // assume path was found; let's show it
            while (current != null)
            {
                Console.SetCursorPosition(current.A, current.B);
                Console.Write('+');
                Console.SetCursorPosition(current.A, current.B);
                current = current.Origin;
                System.Threading.Thread.Sleep(1000);
            }

            Console.Write("You have found the shortest path");
            Console.ReadLine(); 

        }
        static List<grid> AsquareOpen(int x, int y, string[] map)
        {
            var proposedLocations = new List<grid>()
            {
                new grid { A = x, B = y - 1 },
                new grid { A = x, B = y + 1 },
                new grid { A = x - 1, B = y },
                new grid { A = x + 1, B = y },
            };

            return proposedLocations.Where(l => map[l.B][l.A] == ' ' || map[l.B][l.A] == 'B').ToList();
        }
        static int ComputeHScore(int x, int y, int targetX, int targetY)
        {
            return Math.Abs(targetX - x) + Math.Abs(targetY - y);
        }
    }
}
